module.exports = {
	/**
	 * @type {string}
	 * @description 首页三张背景图
	 */
	bg1: 'https://cdn.jsdelivr.net/gh/Taoxier/resources/img8.jpg',
	bg2: 'https://cdn.jsdelivr.net/gh/Taoxier/resources/img8.jpg',
	bg3: 'https://cdn.jsdelivr.net/gh/Taoxier/resources/img8.jpg',

	/**
	 * @type {string}
	 * @description 首页故障风文字
	 */
	malfunctionText: 'Taoxier\'s Blog'
}
